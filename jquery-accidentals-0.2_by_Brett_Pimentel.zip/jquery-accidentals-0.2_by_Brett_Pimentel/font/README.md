#Accidentals font

A lightweight web font containing only musical symbols: flat, sharp, natural, double-flat, and double-sharp. Created for use with [jQuery Accidentals](https://github.com/bpimentel/accidentals).

Full documentation and latest stable release at [accidentals.bretpimentel.com](http://accidentals.bretpimentel.com)